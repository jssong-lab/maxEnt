Files *_train.data contain 2000 dinucleotide assigned to classes 0 or 1 according to an XOR logic and used to for network training.

dinucleotide is in class 1 if exactly one of the following conditions is satisified:
	+ sequence position 0 is A or T
	+ sequence position 1 is G
Otherwise dinucleotide is in class 0
